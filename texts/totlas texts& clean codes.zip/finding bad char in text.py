﻿#!/usr/bin/python
# -*- coding: utf-8 -*-
# Reza1615
# Distributed under the terms of the CC-BY-SA 3.0 .

import codecs
from collections import defaultdict
filesample = 'total2.txt'
text = codecs.open( filesample,'r' ,'utf8' )
text = text.read()

for i in u"qwertyuiop[]\';lkjhgfdsazxcvbnm﻿‎–”…üç○●©,./`QWERTYUIOP[]\';LKJHGFDSA\ZXCVBNM,./1234567890-=!@#$%^&*()_+~q}{|:lk?><mn|"+u'"'+u"چجحخهعغفقثصض\گکمنتالبیسش/.وپدذرزطظًٌٍَُِّْ][}{|؛:«»ةآأإيئؤكٓژٰ‌ٔء><؟÷‍"+u"‍۱۲۳۴۵۶۷۸۹۰-=!٬٫﷼٪×،*)(ـ+"+u'٩٣٠١٢٤٥٧'+u'۱۲۳۴۵۶۷۸۹۰0123456789'+u'[]?{}()؟.،)(»«!':     
     text=text.replace(i,u'').replace(u' ',u'').replace(u'\n',u'').replace(u'‌',u'').replace(u'\r',u'')
text2=u'\n'
for i in text:
    if not i in text2:
        text2+=i
with codecs.open('total3.txt' ,mode = 'w',encoding = 'utf8' ) as f:
                    f.write( text2)

    